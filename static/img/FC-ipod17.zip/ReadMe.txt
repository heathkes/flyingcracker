FlyingCracker Cocktails v1.6

To install:
Drag the "FlyingCracker" folder into the "Notes" folder on your iPod.

That was simple, wasn't it?

Enjoy the recipes and please drink responsibly.